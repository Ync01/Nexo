// menuBG.js
document.addEventListener('DOMContentLoaded', function() {
    const hamburguer = document.querySelector('.hamburguer');
    
    if (hamburguer) {
        hamburguer.addEventListener('click', () => {
            document.querySelector('.navHeader').classList.toggle('active');
        });
    }
});